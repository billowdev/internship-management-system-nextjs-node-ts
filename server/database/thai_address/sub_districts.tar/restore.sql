--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.3
-- Dumped by pg_dump version 14.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE internship_management_system_db;
--
-- Name: internship_management_system_db; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE internship_management_system_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_United States.1252';


ALTER DATABASE internship_management_system_db OWNER TO postgres;

\connect internship_management_system_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: sub_districts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sub_districts (
    id character varying(8) NOT NULL,
    code character varying(6),
    name_th character varying(150),
    name_en character varying(150),
    district_id character varying(5)
);


ALTER TABLE public.sub_districts OWNER TO postgres;

--
-- Data for Name: sub_districts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sub_districts (id, code, name_th, name_en, district_id) FROM stdin;
\.
COPY public.sub_districts (id, code, name_th, name_en, district_id) FROM '$$PATH$$/3361.dat';

--
-- Name: sub_districts sub_districts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_districts
    ADD CONSTRAINT sub_districts_pkey PRIMARY KEY (id);


--
-- Name: sub_districts sub_districts_district_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_districts
    ADD CONSTRAINT sub_districts_district_id_fkey FOREIGN KEY (district_id) REFERENCES public.districts(id);


--
-- PostgreSQL database dump complete
--

