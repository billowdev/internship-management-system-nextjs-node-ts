--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.3
-- Dumped by pg_dump version 14.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE internship_management_system_db;
--
-- Name: internship_management_system_db; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE internship_management_system_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_United States.1252';


ALTER DATABASE internship_management_system_db OWNER TO postgres;

\connect internship_management_system_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: enum_Address_address_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_Address_address_type" AS ENUM (
    'hometown',
    'present',
    'company',
    'contact_person'
);


ALTER TYPE public."enum_Address_address_type" OWNER TO postgres;

--
-- Name: enum_Company_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_Company_type" AS ENUM (
    'รัฐบาล',
    'เอกชน',
    'รัฐวิสาหกิจ'
);


ALTER TYPE public."enum_Company_type" OWNER TO postgres;

--
-- Name: enum_User_roles; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_User_roles" AS ENUM (
    'admin',
    'director',
    'student'
);


ALTER TYPE public."enum_User_roles" OWNER TO postgres;

--
-- Name: enum_addresses_address_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_addresses_address_type AS ENUM (
    'hometown',
    'present',
    'company',
    'contact_person'
);


ALTER TYPE public.enum_addresses_address_type OWNER TO postgres;

--
-- Name: enum_companies_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_companies_type AS ENUM (
    'รัฐบาล',
    'เอกชน',
    'รัฐวิสาหกิจ'
);


ALTER TYPE public.enum_companies_type OWNER TO postgres;

--
-- Name: enum_users_roles; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_users_roles AS ENUM (
    'admin',
    'director',
    'student'
);


ALTER TYPE public.enum_users_roles OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: SequelizeMeta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SequelizeMeta" (
    name character varying(255) NOT NULL
);


ALTER TABLE public."SequelizeMeta" OWNER TO postgres;

--
-- Name: addresses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.addresses (
    id uuid NOT NULL,
    house_number character varying(10),
    road character varying(50),
    village character varying(50),
    sub_district character varying(150),
    district character varying(150),
    province character varying(150),
    zip_code character varying(10),
    address_type public.enum_addresses_address_type,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.addresses OWNER TO postgres;

--
-- Name: co_internships; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.co_internships (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    internship_id uuid NOT NULL,
    student_id character varying(11) NOT NULL
);


ALTER TABLE public.co_internships OWNER TO postgres;

--
-- Name: co_internships_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.co_internships_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.co_internships_id_seq OWNER TO postgres;

--
-- Name: co_internships_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.co_internships_id_seq OWNED BY public.co_internships.id;


--
-- Name: companies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.companies (
    id uuid NOT NULL,
    contact_person_name character varying(100),
    contact_person_position character varying(50),
    contact_person_phone character varying(10),
    name character varying(100),
    type public.enum_companies_type DEFAULT 'รัฐบาล'::public.enum_companies_type NOT NULL,
    activities character varying(100),
    propose_to character varying(40),
    phone character varying(10),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    address_id uuid NOT NULL
);


ALTER TABLE public.companies OWNER TO postgres;

--
-- Name: contact_people; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contact_people (
    id uuid NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    relationship character varying(20),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    address_id uuid NOT NULL,
    student_id character varying(11) NOT NULL
);


ALTER TABLE public.contact_people OWNER TO postgres;

--
-- Name: directors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.directors (
    id character varying(11) NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    phone character varying(10),
    program character varying(50),
    department character varying(50),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    user_id uuid NOT NULL
);


ALTER TABLE public.directors OWNER TO postgres;

--
-- Name: districts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.districts (
    id character varying(5) NOT NULL,
    code character varying(5),
    name_th character varying(150),
    name_en character varying(150),
    province_id character varying(5)
);


ALTER TABLE public.districts OWNER TO postgres;

--
-- Name: education; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.education (
    id uuid NOT NULL,
    academy character varying(100),
    level character varying(100),
    gpa real,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    student_id character varying(11) NOT NULL
);


ALTER TABLE public.education OWNER TO postgres;

--
-- Name: hometown_addresses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.hometown_addresses (
    id integer NOT NULL,
    student_id character varying(11),
    address_id uuid,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.hometown_addresses OWNER TO postgres;

--
-- Name: hometown_addresses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.hometown_addresses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hometown_addresses_id_seq OWNER TO postgres;

--
-- Name: hometown_addresses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.hometown_addresses_id_seq OWNED BY public.hometown_addresses.id;


--
-- Name: internships; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.internships (
    id uuid NOT NULL,
    is_send boolean DEFAULT false,
    is_confirm boolean DEFAULT false,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    student_id character varying(11) NOT NULL,
    company_id uuid NOT NULL
);


ALTER TABLE public.internships OWNER TO postgres;

--
-- Name: present_addresses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.present_addresses (
    id integer NOT NULL,
    student_id character varying(11),
    address_id uuid,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.present_addresses OWNER TO postgres;

--
-- Name: present_addresses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.present_addresses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.present_addresses_id_seq OWNER TO postgres;

--
-- Name: present_addresses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.present_addresses_id_seq OWNED BY public.present_addresses.id;


--
-- Name: provinces; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.provinces (
    id character varying(5) NOT NULL,
    code character varying(5),
    name_th character varying(150),
    name_en character varying(150)
);


ALTER TABLE public.provinces OWNER TO postgres;

--
-- Name: students; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.students (
    id character varying(11) NOT NULL,
    email character varying(150),
    id_card character varying(13),
    first_name character varying(75) NOT NULL,
    last_name character varying(75) NOT NULL,
    phone character varying(10),
    program character varying(50) NOT NULL,
    department character varying(50) NOT NULL,
    skill character varying(255),
    interest character varying(255),
    project_topic character varying(50),
    date_of_birth date,
    experience character varying(255),
    religion character varying(20),
    father_name character varying(150),
    father_job character varying(50),
    mother_name character varying(150),
    mother_job character varying(50),
    present_gpa real,
    image character varying(255),
    resume_status boolean DEFAULT false,
    is_cointernship boolean,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    user_id uuid NOT NULL
);


ALTER TABLE public.students OWNER TO postgres;

--
-- Name: sub_districts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sub_districts (
    id character varying(8) NOT NULL,
    code character varying(6),
    name_th character varying(150),
    name_en character varying(150),
    district_id character varying(5)
);


ALTER TABLE public.sub_districts OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    username character varying(100) NOT NULL,
    password character varying(100) NOT NULL,
    roles public.enum_users_roles DEFAULT 'student'::public.enum_users_roles NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: co_internships id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.co_internships ALTER COLUMN id SET DEFAULT nextval('public.co_internships_id_seq'::regclass);


--
-- Name: hometown_addresses id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hometown_addresses ALTER COLUMN id SET DEFAULT nextval('public.hometown_addresses_id_seq'::regclass);


--
-- Name: present_addresses id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.present_addresses ALTER COLUMN id SET DEFAULT nextval('public.present_addresses_id_seq'::regclass);


--
-- Data for Name: SequelizeMeta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SequelizeMeta" (name) FROM stdin;
\.
COPY public."SequelizeMeta" (name) FROM '$$PATH$$/3436.dat';

--
-- Data for Name: addresses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.addresses (id, house_number, road, village, sub_district, district, province, zip_code, address_type, created_at, updated_at) FROM stdin;
\.
COPY public.addresses (id, house_number, road, village, sub_district, district, province, zip_code, address_type, created_at, updated_at) FROM '$$PATH$$/3437.dat';

--
-- Data for Name: co_internships; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.co_internships (id, created_at, updated_at, internship_id, student_id) FROM stdin;
\.
COPY public.co_internships (id, created_at, updated_at, internship_id, student_id) FROM '$$PATH$$/3450.dat';

--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.companies (id, contact_person_name, contact_person_position, contact_person_phone, name, type, activities, propose_to, phone, created_at, updated_at, address_id) FROM stdin;
\.
COPY public.companies (id, contact_person_name, contact_person_position, contact_person_phone, name, type, activities, propose_to, phone, created_at, updated_at, address_id) FROM '$$PATH$$/3447.dat';

--
-- Data for Name: contact_people; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contact_people (id, first_name, last_name, relationship, created_at, updated_at, address_id, student_id) FROM stdin;
\.
COPY public.contact_people (id, first_name, last_name, relationship, created_at, updated_at, address_id, student_id) FROM '$$PATH$$/3451.dat';

--
-- Data for Name: directors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.directors (id, first_name, last_name, phone, program, department, created_at, updated_at, user_id) FROM stdin;
\.
COPY public.directors (id, first_name, last_name, phone, program, department, created_at, updated_at, user_id) FROM '$$PATH$$/3452.dat';

--
-- Data for Name: districts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.districts (id, code, name_th, name_en, province_id) FROM stdin;
\.
COPY public.districts (id, code, name_th, name_en, province_id) FROM '$$PATH$$/3439.dat';

--
-- Data for Name: education; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.education (id, academy, level, gpa, created_at, updated_at, student_id) FROM stdin;
\.
COPY public.education (id, academy, level, gpa, created_at, updated_at, student_id) FROM '$$PATH$$/3453.dat';

--
-- Data for Name: hometown_addresses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.hometown_addresses (id, student_id, address_id, created_at, updated_at) FROM stdin;
\.
COPY public.hometown_addresses (id, student_id, address_id, created_at, updated_at) FROM '$$PATH$$/3444.dat';

--
-- Data for Name: internships; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.internships (id, is_send, is_confirm, created_at, updated_at, student_id, company_id) FROM stdin;
\.
COPY public.internships (id, is_send, is_confirm, created_at, updated_at, student_id, company_id) FROM '$$PATH$$/3448.dat';

--
-- Data for Name: present_addresses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.present_addresses (id, student_id, address_id, created_at, updated_at) FROM stdin;
\.
COPY public.present_addresses (id, student_id, address_id, created_at, updated_at) FROM '$$PATH$$/3446.dat';

--
-- Data for Name: provinces; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.provinces (id, code, name_th, name_en) FROM stdin;
\.
COPY public.provinces (id, code, name_th, name_en) FROM '$$PATH$$/3438.dat';

--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.students (id, email, id_card, first_name, last_name, phone, program, department, skill, interest, project_topic, date_of_birth, experience, religion, father_name, father_job, mother_name, mother_job, present_gpa, image, resume_status, is_cointernship, created_at, updated_at, user_id) FROM stdin;
\.
COPY public.students (id, email, id_card, first_name, last_name, phone, program, department, skill, interest, project_topic, date_of_birth, experience, religion, father_name, father_job, mother_name, mother_job, present_gpa, image, resume_status, is_cointernship, created_at, updated_at, user_id) FROM '$$PATH$$/3442.dat';

--
-- Data for Name: sub_districts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sub_districts (id, code, name_th, name_en, district_id) FROM stdin;
\.
COPY public.sub_districts (id, code, name_th, name_en, district_id) FROM '$$PATH$$/3440.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, password, roles, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.users (id, username, password, roles, is_active, created_at, updated_at) FROM '$$PATH$$/3441.dat';

--
-- Name: co_internships_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.co_internships_id_seq', 1, false);


--
-- Name: hometown_addresses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.hometown_addresses_id_seq', 1, false);


--
-- Name: present_addresses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.present_addresses_id_seq', 1, false);


--
-- Name: SequelizeMeta SequelizeMeta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SequelizeMeta"
    ADD CONSTRAINT "SequelizeMeta_pkey" PRIMARY KEY (name);


--
-- Name: addresses addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.addresses
    ADD CONSTRAINT addresses_pkey PRIMARY KEY (id);


--
-- Name: co_internships co_internships_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.co_internships
    ADD CONSTRAINT co_internships_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: contact_people contact_people_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact_people
    ADD CONSTRAINT contact_people_pkey PRIMARY KEY (id);


--
-- Name: directors directors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.directors
    ADD CONSTRAINT directors_pkey PRIMARY KEY (id);


--
-- Name: districts districts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.districts
    ADD CONSTRAINT districts_pkey PRIMARY KEY (id);


--
-- Name: education education_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.education
    ADD CONSTRAINT education_pkey PRIMARY KEY (id);


--
-- Name: hometown_addresses hometown_addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hometown_addresses
    ADD CONSTRAINT hometown_addresses_pkey PRIMARY KEY (id);


--
-- Name: internships internships_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.internships
    ADD CONSTRAINT internships_pkey PRIMARY KEY (id);


--
-- Name: present_addresses present_addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.present_addresses
    ADD CONSTRAINT present_addresses_pkey PRIMARY KEY (id);


--
-- Name: provinces provinces_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provinces
    ADD CONSTRAINT provinces_pkey PRIMARY KEY (id);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (id);


--
-- Name: sub_districts sub_districts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_districts
    ADD CONSTRAINT sub_districts_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: co_internships co_internships_internship_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.co_internships
    ADD CONSTRAINT co_internships_internship_id_fkey FOREIGN KEY (internship_id) REFERENCES public.internships(id);


--
-- Name: co_internships co_internships_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.co_internships
    ADD CONSTRAINT co_internships_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id);


--
-- Name: companies companies_address_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_address_id_fkey FOREIGN KEY (address_id) REFERENCES public.addresses(id);


--
-- Name: contact_people contact_people_address_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact_people
    ADD CONSTRAINT contact_people_address_id_fkey FOREIGN KEY (address_id) REFERENCES public.addresses(id);


--
-- Name: contact_people contact_people_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact_people
    ADD CONSTRAINT contact_people_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id);


--
-- Name: directors directors_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.directors
    ADD CONSTRAINT directors_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: districts districts_province_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.districts
    ADD CONSTRAINT districts_province_id_fkey FOREIGN KEY (province_id) REFERENCES public.provinces(id);


--
-- Name: education education_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.education
    ADD CONSTRAINT education_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id);


--
-- Name: hometown_addresses hometown_addresses_address_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hometown_addresses
    ADD CONSTRAINT hometown_addresses_address_id_fkey FOREIGN KEY (address_id) REFERENCES public.addresses(id);


--
-- Name: hometown_addresses hometown_addresses_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hometown_addresses
    ADD CONSTRAINT hometown_addresses_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id);


--
-- Name: internships internships_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.internships
    ADD CONSTRAINT internships_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: internships internships_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.internships
    ADD CONSTRAINT internships_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id);


--
-- Name: present_addresses present_addresses_address_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.present_addresses
    ADD CONSTRAINT present_addresses_address_id_fkey FOREIGN KEY (address_id) REFERENCES public.addresses(id);


--
-- Name: present_addresses present_addresses_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.present_addresses
    ADD CONSTRAINT present_addresses_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id);


--
-- Name: students students_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: sub_districts sub_districts_district_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_districts
    ADD CONSTRAINT sub_districts_district_id_fkey FOREIGN KEY (district_id) REFERENCES public.districts(id);


--
-- PostgreSQL database dump complete
--

